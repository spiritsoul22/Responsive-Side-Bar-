# Responsive Sidebar Menu
## [Watch it on youtube](https://youtu.be/C6227evfBig)
### Responsive Sidebar Menu
Beautiful and simple sidebar menu, contains a logo and link icons. Include in the header a button that shows and hides the sidebar.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
